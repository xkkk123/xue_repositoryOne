const config={
    host:'localhost',
    user:'root',
    password:'root',
    database:'furit'
}

module.exports=config;