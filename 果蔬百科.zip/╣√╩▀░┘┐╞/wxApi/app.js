const express=require('express');
const fs=require('fs')
const multiparty=require('multiparty');
const cors=require('cors')
const {expressjwt}=require('express-jwt');
const app=express();

const userRouter=require('./controller/userController');
const dynamicRouter=require('./controller/dynamicController');
const articleRouter=require('./controller/articleController');
const commentsRouter=require('./controller/commentsController');
const mallRouter=require('./controller/mallController');
const appraiseRouter=require('./controller/appraiseController');
const addressRouter=require('./controller/addressController');
const shopCarRouter=require('./controller/shopCarController');
const orderRouter=require('./controller/orderController');
const nutritionRouter=require('./controller/nutritionController');

const secretKey='xuekai'
app.use(express.urlencoded({ extended: false }))
app.use(express.json());
app.use(cors())
app.use(expressjwt({ secret: secretKey,algorithms:['HS256']}).unless({path:[/^(\/login|\/uploads|\/register|\/getMallData|\/getAppraise|\/getImgAppraise|\/getNewAppraise|\/temp|\/getReplyLevel|\/getArticle|\/getMallInfo|\/getReward|\/getComments|\/getSearchArticle|\/getSearchUser|\/getSearchBaike|\/getBaike|\/getDisease)/]}))

app.post('/uploads',function(req,res){
    let form=new multiparty.Form({uploadDir:'./temp'})
    form.parse(req,(err,msg,files)=>{
      
     const file=files['avatarUrl'][0]
     console.log(files,__dirname,form.uploadDir);
     const newPath=__dirname+"/"+form.uploadDir.substring(1)+'/'+file.originalFilename;
     const path=req.protocol+"://"+req.headers.host+form.uploadDir.substring(1)+'/'+file.originalFilename;
      fs.rename(file.path,newPath,(err)=>{
        if (err) {
          console.log(err);
        }
        res.sendStatus=200;
        res.send({
            code:200,
            msg:'图片上传成功',
            path:path
        })
        console.log(path);
      })
    })
})

app.post('/api/uploadAvatar',function(req,res){
  let form=new multiparty.Form({uploadDir:'./uploads'})
  form.parse(req,(err,msg,files)=>{
    
   const file=files['avatarUrl'][0]
   console.log(files,__dirname,form.uploadDir);
   const newPath=__dirname+"/"+form.uploadDir.substring(1)+'/'+file.originalFilename;
   const path=req.protocol+"://"+req.headers.host+form.uploadDir.substring(1)+'/'+file.originalFilename;
    fs.rename(file.path,newPath,(err)=>{
      if (err) {
        console.log(err);
      }
      res.sendStatus=200;
      res.send({
          code:200,
          msg:'图片上传成功',
          path:path
      })
      console.log(path);
    })
  })
})

app.use(function (err, req, res, next) {
    if (err.name === "UnauthorizedError") {
      res.status(401).send("invalid token...");
    } else {
      next(err);
    }
});

app.use([userRouter,dynamicRouter,articleRouter,commentsRouter,mallRouter,appraiseRouter,addressRouter,shopCarRouter,orderRouter,nutritionRouter])

app.use('/uploads',express.static('uploads'))
app.use('/temp',express.static('temp'))
app.listen(8082,function(){
    console.log("启动成功")

})