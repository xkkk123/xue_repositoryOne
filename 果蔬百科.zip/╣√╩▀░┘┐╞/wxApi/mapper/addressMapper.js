const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    getArea:'SELECT area_id,name FROM dou_area WHERE parent_id=?',
    getAddress:'SELECT * FROM address WHERE id=?',
    insertAddress:'INSERT INTO address(userid,username,area,detail_area,phone,defaults)VALUES(?,?,?,?,?,?)',
    deleteAddress:'DELETE FROM address WHERE id=?',
    updateAddress:'UPDATE address SET username=?,area=?,detail_area=?,phone=?,defaults=? WHERE id=?'
}

exports.getArea=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getArea,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getAddress=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getAddress,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertAddress=((address)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.insertAddress,[address.userid,address.username,address.area,address.detail_area,address.phone,address.defaults],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.deleteAddress=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.deleteAddress,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updateAddress=((address)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.updateAddress,[address.username,address.area,address.detailArea,address.phone,address.defaults,address.id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})