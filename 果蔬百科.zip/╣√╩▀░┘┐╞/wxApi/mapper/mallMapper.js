const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryLimit:'SELECT * FROM mall LIMIT ?,? ',
    queryById:'SELECT * FROM mall WHERE id=?',
    queryUser:'SELECT username,avatar FROM user WHERE id=?',
    queryComments:'SELECT *FROM comments WHERE id=?'
}

exports.queryLimit=(limit)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryLimit,[(limit.page*1-1)*limit.line,limit.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryById=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryById,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryUser=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryUser,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryComments=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryComments,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

