const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryByUserName:"SELECT *FROM user WHERE username=?",
    queryById:"SELECT *FROM user WHERE id=?",
    queryUser:"SELECT id,username,avatar FROM user WHERE id=?",
    insertUser:"INSERT INTO user(username,password,avatar) VALUES(?,?,?)",
    updataUser:"UPDATE user SET username=?,password=?,avatar=?,sex=?,area=?,introduction=? WHERE id=?",
    queryTsan:"SELECT *FROM tsan WHERE rep_userid=? LIMIT ?,?",
    queryLike:"SELECT *FROM tsan WHERE userid=? LIMIT ?,?",
    getUsername:"SELECT username,avatar FROM user WHERE id=?",
    getComments:"SELECT articleid,content FROM comments WHERE id=?",
    getArticle:"SELECT id,title FROM article WHERE id=?",
    insertLike:"INSERT INTO tsan(userid,articleid,commentid,rep_userid,date)VALUES(?,?,?,?,?)",
    queryWhether:"SELECT *FROM tsan WHERE userid=? AND articleid=? AND commentid=?",
    deleteLike:"DELETE FROM tsan WHERE userid=? AND articleid=? AND commentid=?",
    getConcern:"SELECT id,rep_userid FROM concern WHERE userid=?",
    getRepConcern:"SELECT id FROM concern WHERE userid=? AND rep_userid=?",
    deleteConcern:"DELETE FROM concern WHERE userid=? AND rep_userid=?",
    insertConcern:"INSERT INTO concern(userid,rep_userid)VALUES(?,?)",
    getFans:"SELECT id,rep_userid,state FROM fans WHERE userid=?",
    updataFans:"UPDATE fans SET state=? WHERE userid=? AND rep_userid=?",
    deleteFans:"DELETE FROM fans WHERE userid=? AND rep_userid=?",
    insertFans:"INSERT INTO fans(userid,rep_userid)VALUES(?,?)",
    getReply:"SELECT userid,content,articleid,level,date,commentid FROM comments WHERE rep_userid=?",
    getReplyByCommentid:"SELECT content FROM comments WHERE id=?",
    getArticleId:'SELECT articleid FROM history WHERE userid=?',
    getArticleHistory:'SELECT id,title,date,readings FROM article WHERE id=?',
    getArticle:'SELECT *FROM article WHERE id=?',
    getMineArticle:'SELECT id,title,date,readings FROM article WHERE userid=?',
    getMineComments:'SELECT content,articleid,date FROM comments WHERE userid=?',
    getCommentsArticle:'SELECT userid,title FROM article WHERE id=?',
    getAddress:'SELECT area_id,name FROM dou_area WHERE parent_id=?',
    updateArticleReplys:'UPDATE article SET replys=? WHERE id=?',
    queryUserPoints:'SELECT points FROM user WHERE id=?',
    updateUserPoints:'UPDATE user SET points=? WHERE id=?',
    updateArticleFavorite:'UPDATE article SET favorite=? WHERE id=?',
    queryTsanCount:'SELECT COUNT(id) FROM tsan WHERE userid=?',
    queryConcernCount:'SELECT COUNT(id) FROM concern WHERE userid=?',
    queryFansCount:'SELECT COUNT(id) FROM fans WHERE userid=?',
}

exports.queryById=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryById,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.queryUser=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryUser,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.queryWhether=((tsan)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryWhether,[tsan.userid*1,tsan.articleid*1,tsan.commentid*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.deleteLike=((tsan)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.deleteLike,[tsan.userid*1,tsan.articleid*1,tsan.commentid*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getArticle=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getArticle,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})


exports.getComments=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getComments,[id],(err,comments)=>{
                resolve({
                    comments,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getUsername=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getUsername,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryByUserName=((username)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryByUserName,[username],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryTsan=((query)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryTsan,[query.id,(query.page*1-1)*query.line,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryLike=((query)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryLike,[query.id,(query.page*1-1)*query.line,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertUser=((user)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.insertUser,[user.username,user.password,user.avatarUrl],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertLike=((tsan)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.insertLike,[tsan.userid*1,tsan.articleid*1,tsan.commentid*1,tsan.rep_userid*1,tsan.date],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updataUser=((user)=>{
    console.log(user);
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.updataUser,[user.username,user.password,user.avatar,user.sex,user.area,user.introduction,user.id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getConcern=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getConcern,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getRepConcern=((userid,rep_userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getRepConcern,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.deleteConcern=((userid,rep_userid)=>{

    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.deleteConcern,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertConcern=((userid,rep_userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.insertConcern,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.deleteFans=((userid,rep_userid)=>{

    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.deleteFans,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getFans=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getFans,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updataFans=((userid,rep_userid,state)=>{

    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.updataFans,[state,userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertFans=((userid,rep_userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if (err) {
                reject(err)
            }
            connection.query(sql.insertFans,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getReply=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getReply,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getReplyByCommentid=((commentid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getReplyByCommentid,[commentid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getArticleId=((userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getArticleId,[userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getArticleHistory=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getArticleHistory,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getMineArticle=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getMineArticle,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getArticle=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getArticle,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getMineComments=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getMineComments,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.getCommentsArticle=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getCommentsArticle,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})


exports.updateArticleReplys=((replys,id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.updateArticleReplys,[replys,id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryUserPoints=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryUserPoints,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updateUserPoints=((points,id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.updateUserPoints,[points,id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updateArticleFavorite=(favorite,id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.updateArticleFavorite,[favorite,id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryTsanCount=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryTsanCount,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryFansCount=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryFansCount,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryConcernCount=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryConcernCount,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})