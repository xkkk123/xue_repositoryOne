const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryOrders:'SELECT * FROM orders WHERE userid=?',
    queryAdress:"SELECT * FROM address WHERE userid=?",
    insertOrders:'INSERT INTO orders(userid,mallid,number,price,goods_name,goods_image,goods_type,category)VALUES(?,?,?,?,?,?,?,?)',
    deleteAddress:'DELETE FROM orders WHERE id=?',
    updateAddress:'UPDATE orders SET username=?,area=?,detail_area=?,phone=?,default=? WHERE id=?',
    queryPoints:'SELECT points FROM user WHERE id=?',
    updatePoints:'UPDATE user SET points WHERE id=?'
}

exports.queryAddress=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryAdress,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryPoints=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryPoints,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.updatePoints=((points,id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.updatePoints,[points,id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.queryOrders=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.queryOrders,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

exports.insertOrders=((orders)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.insertOrders,[orders.userid,orders.mallid,orders.number,orders.price,orders.goods_name,orders.goods_image,orders.goods_type,orders.category],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
// exports.deleteAddress=((id)=>{
//     return new Promise((resolve, reject) => {
//         pool.getConnection((err,connection)=>{
//             if(err){
//                 reject(err)
//             }
//              connection.query(sql.deleteAddress,[id],(err,result)=>{
//                 resolve({
//                     result,
//                     err
//                 })
//             })
//             connection.end();
//         })
//     })
// })
// exports.updateAddress=((address)=>{
//     return new Promise((resolve, reject) => {
//         pool.getConnection((err,connection)=>{
//             if(err){
//                 reject(err)
//             }
//              connection.query(sql.updateAddress,[address.username,address.area,address.detail_area,address.phone,address.default],(err,result)=>{
//                 resolve({
//                     result,
//                     err
//                 })
//             })
//             connection.end();
//         })
//     })
// })