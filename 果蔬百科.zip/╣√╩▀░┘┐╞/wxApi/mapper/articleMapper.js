const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryLimit:'SELECT * FROM article LIMIT ?,? ',
    queryUser:'SELECT id,username,avatar FROM user WHERE id=?',
    queryComments:'SELECT *FROM comments WHERE id=?',
    queryCount:'SELECT COUNT(id) FROM comments WHERE articleid=? AND level=1' ,
    queryArticle:'SELECT * FROM article LIMIT ?,? ',
    getMinePoints:'SELECT points FROM user WHERE id=?',
    queryReward:'SELECT * FROM article WHERE category=? LIMIT ?,? ',
    insertArticle:'INSERT INTO article(userid,title,image,content,date,category,points)VALUES(?,?,?,?,?,?,?)',
   
    getLikeArticle:'SELECT * FROM article WHERE title LIKE ? LIMIT ?,?',
    getLikeUser:'SELECT id,username,avatar FROM user WHERE username LIKE ? LIMIT ?,?',
    getLikeBaike:'SELECT id,synopsis,baike_name,baike_image FROM baike WHERE username LIKE ? LIMIT ?,?',
    queryConcern:'SELECT COUNT(id) FROM concern WHERE userid=? AND rep_userid=?',
    queryTsan:'SELECT COUNT(id) FROM tsan WHERE articleid=?'
}

exports.getLikeArticle=(query,value)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getLikeArticle,[value,(query.page*1-1)*query.line,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryTsan=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryTsan,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}



exports.queryConcern=(userid,rep_userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryConcern,[userid,rep_userid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getLikeUser=(query,value)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getLikeUser,[value,(query.page*1-1)*query.line,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getLikeBaike=(query,value)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getLikeBaike,[value,(query.page*1-1)*query.line,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryLimit=(limit)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryLimit,[(limit.page*1-1)*limit.line,limit.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryReward=(limit,category)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryReward,[category,(limit.page*1-1)*limit.line,limit.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryCount=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryCount,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryUser=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryUser,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getMinePoints=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getMinePoints,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryComments=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryComments,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.insertArticle=(article)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.insertArticle,[article.userid,article.title,article.image,article.content,article.date,article.category,article.points],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}





