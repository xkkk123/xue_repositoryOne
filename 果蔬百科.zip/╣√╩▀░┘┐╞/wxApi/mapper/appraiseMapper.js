const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryAppraise:'SELECT *FROM appraise WHERE mallid=? LIMIT ?,?',
    getTotal:'SELECT COUNT(id) FROM appraise',
    getImgAppraise:'SELECT *FROM appraise WHERE mallid=? AND image IS NOT NULL LIMIT ?,?',
    getImgTotal:'SELECT COUNT(image) FROM appraise',
    getNewAppraise:'select * from appraise WHERE mallid=? ORDER BY date DESC,id DESC  LIMIT ?,?'
}



exports.queryAppraise=(query)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryAppraise,[query.id*1,(query.page*1-1)*query.line*1,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getImgAppraise=(query)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getImgAppraise,[query.id*1,(query.page*1-1)*query.line*1,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getNewAppraise=(query)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getNewAppraise,[query.id*1,(query.page*1-1)*query.line*1,query.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getTotal=()=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getTotal,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getImgTotal=()=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getImgTotal,(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}