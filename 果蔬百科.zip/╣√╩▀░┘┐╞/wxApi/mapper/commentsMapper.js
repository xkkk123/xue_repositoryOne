const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryComments:'SELECT *FROM comments WHERE articleid=? AND level=1',
    queryAnswerComment:'SELECT userid,content,date FROM comments WHERE articleid=? AND level=1',
    queryUser:'SELECT id,username,avatar FROM user WHERE id=?',
    queryByCount:'SELECT COUNT(*) FROM comments WHERE articleid=? AND commentid=? AND level>1',
    queryArticle:'SELECT id,title,replys,points FROM article WHERE userid=? AND category=?',
    getReplyLevel:'SELECT *FROM comments WHERE commentid=? AND level>1',
    insertComments:"INSERT INTO comments(userid,content,articleid,image,level,rep_userid,commentid,date)VALUES(?,?,?,?,?,?,?,?)"
}

exports.queryComments=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryComments,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryAnswerComment=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryAnswerComment,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryArticle=(id,category)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryArticle,[id,category],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.getReplyLevel=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.getReplyLevel,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryByCount=(articleid,commentid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryByCount,[articleid,commentid],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryUser=(id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryUser,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.insertComments=(comment)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.insertComments,[comment.userid,comment.content,comment.articleid,comment.image,comment.level,comment.rep_userid,comment.commentid,comment.date],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}