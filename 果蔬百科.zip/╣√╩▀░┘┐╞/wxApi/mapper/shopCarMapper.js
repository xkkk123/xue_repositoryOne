const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    getShopCar:'SELECT *FROM shop_car WHERE userid=?',
    insertShopCar:'INSERT INTO shop_car(userid,mallid,number,price,goods_name,goods_type,goods_image,category)VALUES(?,?,?,?,?,?,?,?)',
    deleteShopCar:'DELETE FROM shop_car WHERE id=?',
    updateShopCar:'UPDATA shop_car SET number=? WHERE id=?',
}

exports.getShopCar=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.getShopCar,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.insertShopCar=((shop)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.insertShopCar,[shop.userid,shop.mallid,shop.number,shop.price,shop.goods_name,shop.goods_type,shop.goods_image,shop.category],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.deleteShopCar=((id)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.deleteShopCar,[id],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})
exports.updateAddress=((number)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
             connection.query(sql.updateShopCar,[number],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
})

