const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryBaike:'SELECT * FROM baike WHERE kind=?',
    queryDisease:'SELECT * FROM disease',
    queryBaikeType:'SELECT id,text,content FROM baike WHERE type=?'
}

exports.queryBaike=(kind)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryBaike,[kind],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryDisease=()=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryDisease,[],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.queryBaikeType=(type)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryBaikeType,[type],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}