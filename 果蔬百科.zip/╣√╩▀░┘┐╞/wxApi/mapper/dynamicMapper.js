const mysql=require('mysql');
const config=require('../mysql/config');
const pool=mysql.createPool(config);

const sql={
    queryLimit:'SELECT * FROM dynamic WHERE userid=? LIMIT ?,? ',
    insertDynamic:'INSERT INTO dynamic(userid,title,image,date,content)VALUES(?,?,?,?,?)'
}

exports.queryLimit=(limit,userid)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.queryLimit,[userid,(limit.page*1-1)*limit.line,limit.line*1],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}

exports.insertDynamic=(dynamic)=>{
    return new Promise((resolve, reject) => {
        pool.getConnection((err,connection)=>{
            if(err){
                reject(err)
            }
            connection.query(sql.insertDynamic,[dynamic.userid,dynamic.title,dynamic.image,dynamic.date,dynamic.content],(err,result)=>{
                resolve({
                    result,
                    err
                })
            })
            connection.end();
        })
    })
}



