const express=require('express');
const userService=require('../service/userService')
const result=require('../utils/result')

const router=express.Router()

router.post('/login',(req,res,next)=>{
    userService.login(req.body).then(data=>{
        if (data==='密码错误'||data==='账号错误') {
            res.send(result.success(400,data,''))  
            return;
        }
        res.send(result.success(200,'登录成功',data))
    }).catch(err=>{
        res.send(result.fail(400,"登录失败",err))
    })
    
})

router.post('/register',(req,res,next)=>{
    userService.register(req.body).then(data=>{
        if(data.msg==='用户名重复'){
            res.send(result.fail(400,"用户名重复",''))
            return;
        }
        res.send(result.success(200,"注册成功",data))
    }).catch(err=>{
        res.send(result.fail(400,"注册失败",err))
    })
    
})

router.get('/api/getUser',(req,res)=>{
    userService.getUser(req.auth.id).then(data=>{
        res.send(result.success(400,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
    
})

router.put('/api/updataUser',(req,res)=>{
    userService.updateUser(req.body).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
    
})

router.get("/api/getTsan",(req,res,next)=>{
    const query=req.query;
    query.id=req.auth.id
    userService.getTsan(query).then(data=>{
        // console.log(data);
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getLike",(req,res,next)=>{
    const query=req.query;
    query.id=req.auth.id
    userService.getLike(query).then(data=>{
        // console.log(data);
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/setLike",(req,res,next)=>{
    const tsan=req.query
    tsan.userid=req.auth.id;
    console.log(tsan);
    userService.setLike(tsan).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getConcern",(req,res,next)=>{
    userService.getConcern(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/deleteConcern",(req,res,next)=>{
    userService.deleteConcern(req.auth.id,req.query.rep_userid*1).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/setConcern",(req,res,next)=>{
    userService.setConcern(req.auth.id,req.query.rep_userid*1).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/judgmentConcern",(req,res,next)=>{
    userService.judgmentConcern(req.auth.id,req.query.rep_userid*1).then(data=>{
        console.log(data);
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getFans",(req,res,next)=>{
    userService.getFans(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/updataFans",(req,res,next)=>{
    userService.updataFans(req.auth.id,req.query.rep_userid*1,req.query.state).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getReply",(req,res,next)=>{
    userService.getReply(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getArticleHistory",(req,res,next)=>{
    userService.getArticleHistory(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getArticle",(req,res,next)=>{
    userService.getArticle(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getMineArticle",(req,res,next)=>{
    userService.getMineArticle(req.auth.id).then(data=>{
        console.log(data);
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getMineComments",(req,res,next)=>{

    userService.getMineComments(req.auth.id).then(data=>{
        
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.post("/api/setPoints",(req,res,next)=>{
    let orderId=req.body.orderId
    userService.SetPoints(orderId).then((data)=>{
        console.log(data);
        res.send(result.success(200,'success',data))  
    }).catch((err)=>{
        console.log(err);
        res.send(result.fail(400,"fail",err))
    })
})

router.post("/api/setAnswer",(req,res,next)=>{
    userService.setAnswer(req.body.userid,req.body.articleid,req.body.points).then((data)=>{
        res.send(result.success(200,'success',data))  
    }).catch((err)=>{
        console.log(err);
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getTask",(req,res,next)=>{
    userService.getTask().then((data)=>{
        res.send(result.success(200,'success',data))  
    }).catch((err)=>{
        console.log(err);
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router
