const express=require('express');
const commentsService=require('../service/commentsService')
const result=require('../utils/result');

const router=express.Router()


router.get('/getComments',(req,res,next)=>{

    commentsService.getComments(req.query.id).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.post("/api/setReply",(req,res,next)=>{
    const comment=req.body;
    comment.userid=req.auth.id;
    commentsService.setReply(req,comment).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/getReplyLevel",(req,res,next)=>{
    commentsService.getReplyLevel(req.query.commentid*1).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getAnswer",(req,res,next)=>{
    commentsService.getAnswer(req.auth.id).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router

