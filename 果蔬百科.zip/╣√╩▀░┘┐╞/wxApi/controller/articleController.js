const express=require('express');
const articleService=require('../service/articleService')
const result=require('../utils/result');

const router=express.Router()

router.get('/getArticle',(req,res,next)=>{
    articleService.getArticle(req.query).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getReward',(req,res,next)=>{
    articleService.getReward(JSON.parse(req.query.query),req.query.category).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/api/getMinePoints',(req,res,next)=>{
    articleService.getMinePoints(req.auth.id).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getSearchArticle',(req,res,next)=>{
    const query =JSON.parse(req.query.query)
    articleService.getLikeSearch(query,req.query.value).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getSearchUser',(req,res,next)=>{
    console.log(1);
    const query =JSON.parse(req.query.query)
    articleService.getSearchUser(query,req.query.value).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })

})

router.get('/api/getSearchTokenUser',(req,res,next)=>{
    console.log(2);
    const query =JSON.parse(req.query.query)
    articleService.getSearchTokenUser(query,req.auth.id,req.query.value).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getSearchBaike',(req,res,next)=>{
    const query =JSON.parse(req.query.query)
    articleService.getSearchBaike(query,req.query.value).then(data=>{

        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

// router.get('/getTokenSearch',(req,res,next)=>{
//     const query =JSON.parse(req.query.query)
//     articleService.getTokenSearch(query,req.auth.id,req.query.value).then(data=>{

//         res.send(result.success(200,"success",data))
//     }).catch(err=>{
//         res.send(result.fail(400,"fail",err))
//     })
// })

router.post('/api/setArticle',(req,res,next)=>{
    req.body.userid=req.auth.id
    articleService.setArticle(req,req.body).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router