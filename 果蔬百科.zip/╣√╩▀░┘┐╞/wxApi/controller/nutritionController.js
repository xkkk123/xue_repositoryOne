const express=require('express');
const nutritionService=require('../service/nutritionService')
const result=require('../utils/result')

const router=express.Router()

router.get('/getBaike',(req,res,next)=>{
    console.log(req.query);
    nutritionService.getBaike(req.query.kind).then(data=>{
        res.send(result.fail(200,"succerr",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))

    })
})

router.get('/getDisease',(req,res,next)=>{
    nutritionService.getDisease(req.query.kind).then(data=>{
        res.send(result.fail(200,"succerr",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))

    })
})

router.get('/api/getSuggest',(req,res,next)=>{
    nutritionService.getSuggest(req.query).then(data=>{
        res.send(result.fail(200,"succerr",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))

    })
})

module.exports=router