const express=require('express');
const shopCarService=require('../service/shopCarService')
const result=require('../utils/result')

const router=express.Router()


router.post("/api/insertShopCar",(req,res,next)=>{
    const shopCar=req.body;
    shopCar.userid=req.auth.id
    shopCarService.insertShopCar(shopCar).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getShowCar",(req,res,next)=>{
    console.log(req.auth.id);
    shopCarService.getShowCar(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.delete("/api/deleteShopCar",(req,res,next)=>{
    shopCarService.deleteShopCar(req.body.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router