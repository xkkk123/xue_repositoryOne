const express=require('express');
const dynamicService=require('../service/dynamicService')
const result=require('../utils/result')

const router=express.Router()

router.get('/api/loadDynamic',(req,res,next)=>{
    dynamicService.queryLimit(req.query,req.auth.id).then(data=>{
        
       let resData=data.sort((a,b)=>{
            return a.date<b.date ? 1:-1
        })
        getSort(resData)
        res.send(result.success(200,'success',resData))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.post('/api/setDynamic',(req,res,next)=>{
    const dynamic=req.body
    dynamic.userid=req.auth.id
    dynamic.date=new Date()
    dynamicService.setDynamic(req,dynamic).then(data=>{
        res.send(result.success(200,'success',data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

function getSort(result){
    for (let i = 0; i < result.length; i++) {
        let date=new Date(result[i].date)
        result[i].day=(date.getDate()-1)<10?'0'+(date.getDate()-1):date.getDate()-1;
        result[i].month=(date.getMonth()+1)<10?'0'+(date.getMonth()+1):date.getMonth()+1;
        result[i].year=date.getFullYear()
    }
}



module.exports=router