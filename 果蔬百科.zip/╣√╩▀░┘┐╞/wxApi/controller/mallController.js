const express=require('express');
const mallService=require('../service/mallService')
const result=require('../utils/result')

const router=express.Router()

router.get('/getMallData',(req,res,next)=>{
    mallService.getMallData(req.query).then(data=>{
        res.send(result.fail(200,"succerr",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))

    })
})

router.get('/getMallInfo',(req,res,next)=>{
    mallService.getMallInfo(req.query.id*1).then(data=>{
        res.send(result.fail(200,"succerr",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))

    })
})



module.exports=router