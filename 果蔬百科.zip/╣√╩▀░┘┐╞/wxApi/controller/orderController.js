const express=require('express');
const orderService=require('../service/orderService')
const result=require('../utils/result')

const router=express.Router()


router.post("/api/insertOrders",(req,res,next)=>{
    const orders=req.body;
    orders.userid=req.auth.id
    orderService.insertOrders(orders).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.post("/api/setOrders",(req,res,next)=>{
    const orders=req.body;
    orders.userid=req.auth.id

    orderService.setOrders(orders).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getOrders",(req,res,next)=>{
    orderService.getOrders(req.auth.id).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/submitOrder",(req,res,next)=>{
    orderService.submitOrder(req.query.price*1,req.auth.id*1).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router