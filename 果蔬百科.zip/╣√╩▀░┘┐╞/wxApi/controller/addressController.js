const express=require('express');
const addressService=require('../service/addressService')
const result=require('../utils/result')

const router=express.Router()


router.get("/api/getArea",(req,res,next)=>{

    addressService.getArea().then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get("/api/getAddress",(req,res,next)=>{
    console.log(req.query.id);
    addressService.getAddress(req.query.id*1).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.put("/api/updataAddress",(req,res,next)=>{
    addressService.updateAddress(req.body).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.post("/api/setAddress",(req,res,next)=>{
    const address=req.body
    address.userid=req.auth.id
    addressService.setAddress(req.body).then(data=>{
        res.send(result.success(200,'success',data))  
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router