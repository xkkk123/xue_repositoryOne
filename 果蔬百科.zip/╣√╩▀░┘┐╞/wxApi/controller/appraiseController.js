const express=require('express');
const appraiseService=require('../service/appraiseService')
const result=require('../utils/result');

const router=express.Router()


router.get('/getAppraise',(req,res,next)=>{
    appraiseService.getAppraise(req.query).then(data=>{
        // console.log(req.query);
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getImgAppraise',(req,res,next)=>{
    appraiseService.getImgAppraise(req.query).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

router.get('/getNewAppraise',(req,res,next)=>{
    appraiseService.getNewAppraise(req.query).then(data=>{
        res.send(result.success(200,"success",data))
    }).catch(err=>{
        res.send(result.fail(400,"fail",err))
    })
})

module.exports=router

