const appraiseMapper=require('../mapper/appraiseMapper')

exports.getAppraise=async (query)=>{
    try {
        const data=await appraiseMapper.queryAppraise(query);

        const total=await appraiseMapper.getTotal()
        const imgTotal=await appraiseMapper.getImgTotal()

        data.total=total.result[0]['COUNT(id)']
        data.imgTotal=imgTotal.result[0]['COUNT(image)']
        getParse(data.result)
        return data;
    } catch (error) {
        return error
    }
}

exports.getImgAppraise=async (query)=>{
    try {
        const data=await appraiseMapper.getImgAppraise(query);

        getParse(data.result)
        return data;
    } catch (error) {
        return error
    }
}

exports.getNewAppraise=async (query)=>{
    try {
        const data=await appraiseMapper.getNewAppraise(query);

        getParse(data.result)
        return data;
    } catch (error) {
        return error
    }
}

function getParse(result){
    for (let i = 0; i < result.length; i++) {
        result[i].user=JSON.parse(result[i].user)
        if (result[i].image!==null) {
            result[i].image=result[i].image.split(',')
        }
    }
}


