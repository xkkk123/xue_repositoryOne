const articleMapper=require('../mapper/articleMapper')
const setPath=require('../utils/setPath')
const dayjs=require('dayjs')

exports.getArticle=async (limit)=>{
    try {
        const { result } =await articleMapper.queryLimit(limit)
        let item=result;
        for (let i = 0; i < item.length; i++) {
            const { result } = await articleMapper.queryUser(item[i].userid);
            const tsan=await articleMapper.queryTsan(item[i].id)
            if (tsan.result[0]['COUNT(id)']===1) {
                item[i].type=true
            }else{
                item[i].type=false
            }
            item[i].user=result[0]
            item[i].date=dayjs(item.date).format("YYYY-MM-DD")
        }
        console.log(result);
        return result
    } catch (error) {

        return error
    }
}

exports.getReward=async (limit,category)=>{
    try {
        const {result} =await articleMapper.queryReward(limit,category)

        let item=result;
        for (let i = 0; i < item.length; i++) {
            item[i].date=dayjs(item[i].date).format('YYYY-MM-DD')
            const count=await articleMapper.queryCount(item[i].id)
            item[i].count=count.result[0]['COUNT(id)']
            const { result } = await articleMapper.queryUser(item[i].userid);
            item[i].user=result[0]
        }
        
        return result;
    } catch (error) {

        return error
    }
}

exports.getMinePoints=async (id)=>{
    try {
        const {result} =await articleMapper.getMinePoints(id)
        return result[0];
    } catch (error) {

        return error
    }
}

exports.getLikeSearch=async (query,value)=>{
    try {
        // console.log(query,value);
        const values='%'+value+'%'
        const {result} = await articleMapper.getLikeArticle(query,values);
        for (let i = 0; i < result.length; i++) {
           const data= await articleMapper.queryUser(result[i].userid)
            result[i].user=data.result[0]
            result[i].date=dayjs(result[i].date).format('YYYY-MM-DD')
        }
        console.log(result);
        return result;
    } catch (error) {
        return error;
    }
}

exports.getSearchUser=async (query,value)=>{
    try {
        console.log(query,value);
        const values='%'+value+'%'
        const {result} = await articleMapper.getLikeUser(query,values);

        console.log(result);
        return result;
    } catch (error) {
        return error;
    }
}

exports.getSearchTokenUser=async (query,id,value)=>{
    try {
        const values='%'+value+'%'
        const {result} = await articleMapper.getLikeUser(query,values);
        for (let i = 0; i < result.length; i++) {
            if (result[i].id===id) {
                result[i].type='不能对自己操作'
                break;
            }
            const data= await articleMapper.queryConcern(id,result[i].id)
            console.log(data);
            if (data.result[0]['COUNT(id)']===1) {
                result[i].type='已关注'
            }else{
                result[i].type='关注'
            }
        }
        return result;
    } catch (error) {
        return error;
    }
}

exports.getSearchBaike=async (query,value)=>{
    try {
        const values='%'+value+'%'
        const {result} = await articleMapper.getLikeBaike(query,values);
        console.log(result);
        return result;
    } catch (error) {
        return error;
    }
}

exports.setArticle=async (req,article)=>{
    try {
        
        const imageObj=[]
        for (let i = 0; i < article.image; i++) {
            imageObj.push(article.image[i].image)
        }
        setImagePath(req,article.image)
        article.date=new Date()
        article.image=JSON.stringify(article.image)
        console.log(article);
        await articleMapper.insertArticle(article)
        return 'success'
    } catch (error) {

        return error
    }
}


function setImagePath(req,imageArr){
    const arr=[]
    for (let i = 0; i < imageArr.length; i++) {
        arr.push(imageArr[i].image) 
    }
    const newImage=setPath.setPath(req,arr)
    for (let i = 0; i < newImage.length; i++) {
        imageArr[i].image=newImage[i]
    }
}


