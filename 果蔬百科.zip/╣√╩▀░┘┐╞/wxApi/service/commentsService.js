const dayjs = require('dayjs');
const commentsMapper=require('../mapper/commentsMapper')
const setPath=require('../utils/setPath')
const day=require('dayjs')


exports.getComments=async (id)=>{
    try {
        const { result }=await commentsMapper.queryComments(id);
        const item=result;
        for (let i = 0; i < item.length; i++) {
          const { result }= await commentsMapper.queryUser(item[i].userid);
          item[i].user=result[0]
          item[i].date=day(item[i].date).format('YYYY-MM-DD')
          if (item[i].image!==null) {
            item[i].image=JSON.parse(item[i].image)
          }
          
        }
        for (let i = 0; i <item.length; i++) {
            const dataCount= await commentsMapper.queryByCount(id,item[i].id); 
            item[i].count=dataCount.result[0]['COUNT(*)'];
        }
        return result;
    } catch (error) {
        return error
    }
}


exports.getAnswer=async (id)=>{
    try {
        const {result}=await commentsMapper.queryArticle(id,'悬赏问答');
        const item=result
        for (let i = 0; i < item.length; i++) {
          const answerComment= await commentsMapper.queryAnswerComment(item[i].id)
          const answerData= answerComment.result;
          item[i].answer=answerData
            for (let j = 0; j < answerData.length; j++) {
                const user= await commentsMapper.queryUser(answerData[i].userid)
                item[i].answer[j].date=day(item[i].date).format('YYYY-MM-DD');
                item[i].answer[j].user=user.result[0];
            }
        }
        return result;
    } catch (error) {
        return error
    }
}
exports.setReply=async (req,comment)=>{
    try {
        const imageArr=setPath(req,comment.image)
        comment.image=JSON.stringify(imageArr)
        comment.date=new Date()
        const data=await commentsMapper.insertComments(comment);
        return 'result';
    } catch (error) {
        return error
    }
}

exports.getReplyLevel=async (id)=>{
    try {
        const {result}=await commentsMapper.getReplyLevel(id);
        const item=result;
        for (let i = 0; i < item.length; i++) {
          const { result }= await commentsMapper.queryUser(item[i].userid);
          item[i].user=result[0]
          item[i].date=day(item[i].date).format('YYYY-MM-DD')
          if (item[i].image!==null) {
            item[i].image=JSON.parse(item[i].image)
          }
          if (item[i].level===3) {
                const repUserData=await commentsMapper.queryUser(item[i].rep_userid)
                item[i].repUser=repUserData.result[0]
          }else{
                item[i].repUser=null
          }
          
        }
        console.log(result);
        return result;
    } catch (error) {
        return error
    }
}

