const shopCarMapper=require('../mapper/shopCarMapper');


exports.insertShopCar=async (ShopCar)=>{
    try {
        
        const data = await shopCarMapper.insertShopCar(ShopCar);
        console.log(data);
        return result;
    } catch (error) {
        return error;
    }
}

exports.getShowCar=async (id)=>{
    try {
        
        const {result} = await shopCarMapper.getShopCar(id);
        console.log(result);
        return result;
    } catch (error) {
        return error;
    }
}

exports.deleteShopCar=async (id)=>{
    try {
        
        const {result} = await shopCarMapper.deleteShopCar(id);

        return result;
    } catch (error) {
        return error;
    }
}