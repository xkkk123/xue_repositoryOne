const userMapper=require('../mapper/userMapper');
const crypto=require('crypto')
const jwt=require('jsonwebtoken');
const dayjs=require('dayjs')
const md5=crypto.createHash('md5')
const alipaySdk=require('../utils/alipaySdk')
// const AlipayFormData = require('alipay-sdk/lib/form').default;

const mySecret='xuekai'

exports.login=async (user)=>{
    try {
        const newmd5=crypto.createHash('md5')
        const { result }=await userMapper.queryByUserName(user.username);
        console.log(result);

        if (result.length!==0&&result[0].password===newmd5.update(user.password).digest('hex')) {
            const token=jwt.sign({id:result[0].id},mySecret,{expiresIn:'24h'})
            console.log(token);
            return token;
        }else{
            if (result.length===0) 
                return '账号错误';
            return '密码错误';
        }
        
    } catch (error) {
        return error;
    }
}

exports.register=async (user)=>{
    try {
        console.log(user);
        const { result }=await userMapper.queryByUserName(user.username);
        if (result.length===0) {
            user.password=md5.update(user.password).digest('hex');
            const data=await userMapper.insertUser(user)
            return data;
        }
        return { msg:'用户名重复' }
    } catch (error) {
        return error;
    }
}

exports.getUser=async (id)=>{
    try {
        const { result } = await userMapper.queryById(id);

        const tsan= await userMapper.queryTsanCount(id)

        result[0].tsanNum=tsan.result[0]['COUNT(id)']
        const concern= await userMapper.queryConcernCount(id)
        result[0].concernNum=concern.result[0]['COUNT(id)']
        const fans= await userMapper.queryFansCount(id)
        result[0].fansNum=fans.result[0]['COUNT(id)']
        return result;
    } catch (error) {
        return error;
    }
   

}


exports.getTsan=async (query)=>{
    try {
        const { result } = await userMapper.queryTsan(query);
        const res=new Array(result.length)
        for (let i = 0; i < result.length; i++) {
            const data=await userMapper.getUsername(result[i].userid)
            console.log(data);
            res[i]=data.result[0]
            res[i].date=dayjs(result[i].date).format('YYYY-MM-DD')
            if (result[i].articleid===0) {
                const { comments }=await userMapper.getComments(result[i].commentid)
                res[i].articleid=comments[0].articleid;
                res[i].title=comments[0].content;
                res[i].type='评论'
            }else{
                const data=await userMapper.getArticle(result[i].articleid)
                console.log(data.result[0]);
                res[i].articleid=data.result[0].id;
                res[i].title=data.result[0].title;
                res[i].type='文章'
            }
        }

        return res;
    } catch (error) {
        return error;
    }
   

}

exports.getLike=async (query)=>{
    try {
        const { result } = await userMapper.queryLike(query);
        const res=new Array(result.length)
        for (let i = 0; i < result.length; i++) {
            const data=await userMapper.getUsername(result[i].rep_userid)
            res[i]=data.result[0]
            res[i].date=dayjs(result[i].date).format('YYYY-MM-DD')
            if (result[i].articleid===0) {
                const { comments }=await userMapper.getComments(result[i].commentid)
                res[i].articleid=comments[0].articleid;
                res[i].title=comments[0].content;
                res[i].type='评论'
                
            }else{
                const data=await userMapper.getArticle(result[i].articleid)
                res[i].articleid=data.result[0].id;
                res[i].title=data.result[0].title;
                res[i].type='文章'
            }
        }
        return res;
    } catch (error) {
        return error;
    }
   

}

exports.setLike=async (tsan)=>{
    try {
        const  data  = await userMapper.queryWhether(tsan);
        if (data.result.length===0) {
            tsan.date=new Date()
            const  res  = await userMapper.insertLike(tsan);
            await userMapper.updateArticleFavorite(tsan.favorite*1+1,tsan.articleid*1)
            return {favorite:tsan.favorite*1+1};
        }else{
            const  res  = await userMapper.deleteLike(tsan);
            await userMapper.updateArticleFavorite(tsan.favorite*1-1,tsan.articleid*1)
            return {favorite:tsan.favorite*1-1};
        }
    } catch (error) {
        return error;
    }
}

exports.updateUser=async (user)=>{
    console.log(user);
    try {
        const data= await userMapper.updataUser(user);
        console.log(data);
        return result;
    } catch (error) {
        return error;
    }
   

}

exports.getConcern=async (id)=>{
    try {
        const { result } = await userMapper.getConcern(id);
        const res=[];
        for (let i = 0; i < result.length; i++) {
            const userData = await userMapper.queryUser(result[i].rep_userid);
            res.push(userData.result[0])
            res[i].concernid=result[i].id
        }
        return res;
    } catch (error) {
        return error;
    }
}

exports.deleteConcern=async (userid,rep_userid)=>{
    try {
        console.log(userid,rep_userid);
        const data= await userMapper.deleteConcern(userid,rep_userid);
        console.log(data);
        const concernD =await userMapper.getRepConcern(rep_userid,userid)
        if (concernD.result.length!==0) {
          await userMapper.updataFans(userid,rep_userid,"回关")
        }
        await userMapper.deleteFans(rep_userid,userid)

        return 'success';
    } catch (error) {
        return error;
    }
}

exports.setConcern=async (userid,rep_userid)=>{
    try {
        await userMapper.insertConcern(userid,rep_userid);

        await userMapper.insertFans(rep_userid,userid);

        return 'success';
    } catch (error) {
        return error;
    }
}

exports.getFans=async (id)=>{
    try {
        const { result } = await userMapper.getFans(id);
        const res=[]
        for (let i = 0; i < result.length; i++) {
            const userData = await userMapper.queryUser(result[i].rep_userid);
            res.push(userData.result[0])
            res[i].state=result[i].state;
            res[i].fansid=result[i].id
        }

        return res;
    } catch (error) {
        return error;
    }
}

exports.updataFans=async (userid,rep_userid,state)=>{
    try {
        const data = await userMapper.updataFans(userid,rep_userid,state);
        if (state==="回关") {
            await userMapper.deleteConcern(userid,rep_userid)
            await userMapper.deleteFans(rep_userid,userid)
        }else{
            await userMapper.insertConcern(userid,rep_userid);
            await userMapper.insertFans(rep_userid,userid);
            await userMapper.updataFans(rep_userid,userid,state);
        }

        return data;
    } catch (error) {
        return error;
    }
}

exports.judgmentConcern=async (userid,rep_userid)=>{
    try {
        console.log(userid,rep_userid);
       const {result}=await userMapper.getRepConcern(userid,rep_userid);
       if (result.length===0) {
            return "关注";
       }else{
            return '已关注';
       }
    } catch (error) {
        return error;
    }
}

exports.getReply=async (id)=>{
    try {
        const { result } = await userMapper.getReply(id);
  
        for (let i = 0; i < result.length; i++) {
            const userData = await userMapper.queryUser(result[i].userid);
            const rep_content = await userMapper.getReplyByCommentid(result[i].commentid)
            result[i].user=userData.result[0]
            result[i].rep_content=rep_content.result[0].content

        }
        console.log(result);
        return result;
    } catch (error) {
        return error;
    }
}

exports.getArticleHistory=async (id)=>{
    try {
        const { result } = await userMapper.getArticleId(id);
        const res=[]
        for (let i = 0; i < result.length; i++) {
           const data= await userMapper.getArticleHistory(result[i].articleid)
            data.result[0].date=dayjs(data.result[0].date).format('YYYY-MM-DD')
            res.push(data.result[0])
        }
        return res;
    } catch (error) {
        return error;
    }
}

exports.getArticle=async (id)=>{
    try {
        const { result } = await userMapper.getArticleId(id);
        const res=[]

        for (let i = 0; i < result.length; i++) {
            const data= await userMapper.getArticle(result[i].articleid)
            data.result[0].date=dayjs(data.result[0].date).format('YYYY-MM-DD')
            
            if (data.result[0].image!==null) {
                data.result[0].image=JSON.parse(data.result[0].image)
            }
            res.push(data.result[0])
            const userData=await userMapper.queryUser(data.result[0].userid)
            res[i].user=userData.result[0]
        }
        return res;
    } catch (error) {
        return error;
    }
}

exports.getMineArticle=async (id)=>{
    try {
        console.log(id);
        const { result } = await userMapper.getMineArticle(id);
        for (let i = 0; i < result.length; i++) {
            result[i].date=dayjs(result[i].date).format('YYYY-MM-DD')
        }
        return result;
    } catch (error) {
        return error;
    }
}

exports.getMineComments=async (id)=>{
    try {
        const { result } = await userMapper.getMineComments(id);
        const res=[]
        for (let i = 0; i < result.length; i++) {
            result[i].date=dayjs(result[i].date).format('YYYY-MM-DD')
            res.push(result[i])
            const data=await userMapper.getCommentsArticle(result[i].articleid)
            res[i].title=data.result[0].title
            const rep_user= await userMapper.queryUser(data.result[0].userid)
            res[i].rep_user=rep_user.result[0]
        }
        return res;
    } catch (error) {
        return error;
    }
}

exports.setAnswer=async (userid,articleid,points)=>{
    try {
        await userMapper.updateArticleReplys(1,articleid);
       
        const data= await userMapper.queryUserPoints(userid)
        console.log(data);
        await userMapper.updateUserPoints(data.result[0].points*1+points*1,userid)
        // console.log(data);
        return 'success';
    } catch (error) {
        return error;
    }
}

exports.SetPoints=async (orderId)=>{
    try {
        const bizContent = {
            out_trade_no: orderId,
            product_code: "FAST_INSTANT_TRADE_PAY",
            subject: "abc",
            body: "234",
            total_amount: "0.01"
        }          
        const result = alipaySdk.pageExec('alipay.trade.page.pay', {
            method: 'GET',
            bizContent,
            returnUrl: 'http://www.notify.com/notify'
          })

            console.log(result);
            
            return result
    } catch (error) {
        return error;
    }
}

exports.getTask=async ()=>{
    try {

        return result
    } catch (error) {
        return error;
    }
}