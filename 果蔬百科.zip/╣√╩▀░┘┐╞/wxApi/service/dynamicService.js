const { json } = require('express');
const dynamicMapper=require('../mapper/dynamicMapper');
const setPath=require('../utils/setPath')

exports.queryLimit=async (limit,userid)=>{
    try {
        const { result } =await dynamicMapper.queryLimit(limit,userid)
        for (let i = 0; i < result.length; i++) {
            if (result[i].image!==null) {
                result[i].image=JSON.parse(result[i].image)
            }
        }
        console.log(result);
        return result
    } catch (error) {

        return error
    }
}

exports.setDynamic=async (req,dynamic)=>{
    try {       
        console.log(dynamic);
        const newImage= setPath.setPath(req,dynamic.image);
        dynamic.image=JSON.stringify(newImage)
        await dynamicMapper.insertDynamic(dynamic);
        return 'success'
    } catch (error) {
        return error
    }
}


