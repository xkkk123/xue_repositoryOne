const addressMapper=require('../mapper/addressMapper');



exports.getArea=async ()=>{
    try {
        const { result } = await addressMapper.getArea(0);
        for (let i = 0; i < result.length; i++) {
           const data= await addressMapper.getArea(result[i].area_id);
           result[i].children=data.result
           for (let j = 0; j < result[i].children.length; j++) {
                const data= await addressMapper.getArea(result[i].children[j].area_id);
                result[i].children[j].children=data.result
           }
        }
        return result;
    } catch (error) {
        return error;
    }
}

exports.getAddress=async (id)=>{
    try {
        const { result } = await addressMapper.getAddress(id);
        return result[0];
    } catch (error) {
        return error;
    }
}

exports.updateAddress=async (address)=>{
    try {
        console.log(address);
        const data = await addressMapper.updateAddress(address);
        console.log(data);
        return 'result';
    } catch (error) {
        return error;
    }
}

exports.setAddress=async (address)=>{
    try {
        const {result} = await addressMapper.insertAddress(address);
        console.log(data);
        return result;
    } catch (error) {
        return error;
    }
}

