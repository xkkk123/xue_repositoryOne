const mallMapper=require('../mapper/mallMapper')


exports.getMallData=async (limit)=>{
    try {
        const { result } =await mallMapper.queryLimit(limit)
        getParse(result)
        return result
    } catch (error) {

        return error
    }
}

exports.getMallInfo=async (id)=>{
    try {

        const { result } =await mallMapper.queryById(id)
        getParse(result)
        return result
    } catch (error) {
        return error
    }
}

function getParse(result) {
    for (let i = 0; i < result.length; i++) {
        result[i].types=JSON.parse(result[i].types)
        result[i].image=JSON.parse(result[i].image)
    }
}