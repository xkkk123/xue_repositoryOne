const mallMapper=require('../mapper/nutritionMapper')


exports.getBaike=async (kind)=>{
    try {
        const {result}=await mallMapper.queryBaike(kind)
        return result
    } catch (error) {

        return error
    }
}

exports.getDisease=async (kind)=>{
    try {
        const { result } =await mallMapper.queryDisease(kind)
        
        for (let i = 0; i < result.length; i++) {
            result[i].lack=JSON.parse(result[i].lack)
        }
        console.log(result);
        return result
    } catch (error) {
        return error
    }
}

exports.getSuggest=async (query)=>{
    try {
        console.log(query);
        const { result } =await mallMapper.queryBaikeType(query.type)
        const resArr=setSuggest(result, query.num*1)
        return resArr
    } catch (error) {
        return error
    }
}

function setSuggest(furit,content) {
    let romOne=Math.floor(Math.random()*(furit.length))
    let romTwo=Math.floor(Math.random()*(furit.length))
    let oneNum=0;
    let twoNum=0;
    const arr=[]
    arr.push(furit[romOne],furit[romTwo])
    arr[0].number=0
    arr[1].number=0
    while ((oneNum<=content/2&&arr[0].number*100<1500)||(twoNum<=content/2&&arr[1].number*100<1500)) {
        if (oneNum<content/2&&arr[0].number*100<1500) {
            oneNum+=furit[romOne].content
            arr[0].number+=1
        }
        if (twoNum<content/2&&arr[1].number*100<1500) {
            twoNum+=furit[romTwo].content
            arr[1].number+=1
        }
    }
    // while (sum<content) {
    //     sum+=furit[rom].content
    //     arr.push(furit[rom])
    //     rom=Math.floor(Math.random()*furit.length);
    // }
    return arr;
}