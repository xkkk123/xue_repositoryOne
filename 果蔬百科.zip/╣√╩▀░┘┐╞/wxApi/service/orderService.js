const orderMapper=require('../mapper/orderMapper');


exports.insertOrders=async (orders)=>{
    try {
        const data = await orderMapper.insertOrders(orders);
        return data;
    } catch (error) {
        return error;
    }
}

exports.setOrders=async (orders)=>{
    try {

        for (let i = 0; i < orders.ordersArr.length; i++) {
            orders.ordersArr[i].userid=orders.userid
           const data=await orderMapper.insertOrders(orders.ordersArr[i]);
           console.log(data);
        }
        return 'success';
    } catch (error) {
        return error;
    }
}

exports.getOrders=async (id)=>{
    try {
        const addressData=await orderMapper.queryAddress(id)
        const {result}=await orderMapper.queryOrders(id)
        const res={}
        res.orders=result
        res.address=addressData.result
        return res;
    } catch (error) {
        return error;
    }
}

exports.submitOrder=async (price,id)=>{
    try {
        const {result}=await orderMapper.queryPoints(id)
        let priceMine=result[0].points
        console.log(price);
        if (price>priceMine) {
            return 'fail'
        }else{
            priceMine=priceMine-price;
            const data= await orderMapper.updatePoints(price,id);
            console.log(data);
            return 'success';
        }
       
    } catch (error) {
        return error;
    }
}