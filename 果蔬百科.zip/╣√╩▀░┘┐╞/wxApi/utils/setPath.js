
const fs=require('fs')

exports.setPath=function setPath(req,imgArr){
    for (let i = 0; i < imgArr.length; i++) {
        imgArr[i]=imgArr[i].substring(27)
    }
    const file=fs.readdirSync('./temp')
    const newImageArr=[]
    file.forEach(item => {
        let i=imgArr.includes(item)            
        const oldFile='./temp/'+item;
        const newFile='./uploads/'+item;
        if (i) {
            fs.rename(oldFile,newFile,(err)=>{
              if (err) {
                throw err;
              }
            })
            const path=req.protocol+"://"+req.headers.host+newFile.substring(1)
            newImageArr.push(path);
        }else{
            fs.unlinkSync(oldFile);
        }
    });
    return newImageArr;
}