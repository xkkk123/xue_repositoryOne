// pages/edit/edit.js
// import  {areaList}  from '@vant/area-data';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userShow: false,
    sexShow:false,
    introductionShow:false,
    cityShow:false,
    actions: [
      {
        name: '男',
      },
      {
        name: '女',
      },
      {
        name: '保密',
      }
    ],
    areaList : {
      province_list: {
        110000: '北京市',
        120000: '天津市',
      },
      city_list: {
        110100: '北京市',
        120100: '天津市',
      },
      county_list: {
        110101: '东城区',
        110102: '西城区',
        // ....
      },
    },
    user:{}
  },
  onClick(e){
    switch (e.currentTarget.dataset.idtype) {
      case '1':
        this.setData({ userShow: true });
        break;
      case '2':
        this.setData({ sexShow: true });
        break;
      case '3':
        this.setData({ cityShow: true });
        break;
      case '4':
        this.setData({ introductionShow: true });
        break;
      default:
        break;
    }
  },
  onClose() {
    this.onLoad()
    this.setData(
        { 
          userShow:false,
          sexShow:false,
          introductionShow:false,
          cityShow:false
        }
      );
  },
  onUpdata(){
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    wx.request({
      url: 'http://localhost:8082/api/updataUser',
      method:'PUT',
      header:{'Authorization':token},
      data:this.data.user,
      success:(res)=>{
          wx.showToast({
            title: '修改成功',
          })
          setTimeout(()=>{
            this.onClose()
          },1000)
      }
    })
  },
  onBlur(e){
    if (e.currentTarget.dataset.type==='introduction') {
      this.setData({
        'user.introduction':e.detail.value
      })
    } else {
      this.setData({
        'user.username':e.detail.value
      })
    }

  },
  onSelect(e){
    this.setData({
      'user.sex':e.detail.name
    })
    this.onUpdata()
  },
  onUpload(){
    wx.chooseMedia({
      count:1,
      mediaType:'image',
      sourceType:['album','camera'],
      success:(res)=>{
        this.onChooseImage(res.tempFiles[0].tempFilePath)
      }
    })
  },
  onChooseImage(path){
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    wx.uploadFile({
      filePath: path,
      name: 'avatarUrl',
      url: 'http://localhost:8082/api/uploadAvatar',
      header:{'Authorization':token},
      success:(res)=>{
        this.setData({
          'user.avatar':JSON.parse(res.data).path
        })
        this.onUpdata()
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    wx.request({
      url: 'http://localhost:8082/api/getUser',
      method:'GET',
      header:{'Authorization':token},
      success:(res)=>{
        this.setData({
          user:res.data.data[0]
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})