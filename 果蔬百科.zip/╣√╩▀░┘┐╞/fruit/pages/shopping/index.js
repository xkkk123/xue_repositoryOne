// pages/shopping/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      token:'',
      shopData:[],
      cost:0,
      num:0,
      allShow:false,
      chooseArr:[]
  },
  onGetShowCar(){
    wx.request({
      url: 'http://localhost:8082/api/getShowCar',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        this.setData({
          shopData:res.data.data
        })
        console.log(res);

      }
    })
  },
  onClickShop(e){
    const index=e.currentTarget.dataset.index;
    const {chooseArr}=this.data
    const idx=chooseArr.indexOf(index)

    if (idx===-1) {
      chooseArr.push(index)
      this.setData({
        ['shopData['+index+'].show']:true
      })
    }else{
      chooseArr.splice(idx,1)
      this.setData({
        ['shopData['+index+'].show']:false,
        allShow:false
      })
    }    
    if (chooseArr.length===this.data.shopData.length) {
        this.setData({
          allShow:true
        })
    }
    this.onPrice()
  },
  onChange(e) {
    const index=e.currentTarget.dataset.index;
    this.setData({
      ['shopData['+index+'].number']:e.detail
    })
    this.onPrice()
  },
  onClickAll(){
    const { shopData }=this.data;
    const {chooseArr}=this.data
    if (shopData.length!==chooseArr.length) {
      
        for (let i = 0; i < shopData.length; i++) {
          if (shopData[i].show===false||shopData[i].show===undefined) {
            chooseArr.push(i)
            this.setData({
              ['shopData['+i+'].show']:true,
              allShow:true
            })
            
          }
        }
    }else{
      chooseArr.length=0
      for (let i = 0; i < shopData.length; i++) {
          this.setData({
            ['shopData['+i+'].show']:false,
            allShow:false
          })
      }
    }
    this.onPrice()
  },
  onPrice(){
    const { shopData }=this.data;
    let cost=0;
    for (let i = 0; i < shopData.length; i++) {
      if (shopData[i].show===true) {
        cost+=shopData[i].price*1*shopData[i].number
      }
    }
    this.setData({
      cost:cost*100
    })
  },
  onClickButton(){
    
    const {shopData,chooseArr}=this.data
    if (chooseArr.length===0) {
        wx.showToast({
          title: '请选择商品',
          icon:'error'
        })
    }else{
      const orders=[]
      for (let i = 0; i < chooseArr.length; i++) {
        orders.push(shopData[chooseArr[i]])
      }
      wx.request({
        url: 'http://localhost:8082/api/setOrders',
        method:'POST',
        data:{ordersArr:orders},
        header:{'Authorization':this.data.token},
        success:(res)=>{
          wx.navigateTo({
            url: '/pages/orders/index',
          })
        }
      })
    }


  },
  onDeleteShop(e){
    console.log(e);
    const id=e.currentTarget.dataset.id
    wx.request({
      url: 'http://localhost:8082/api/deleteShopCar',
      method:'DELETE',
      data:{id:id},
      header:{'Authorization':this.data.token},
      success:(res)=>{
        console.log(res);
        this.onLoad()
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
    this.onGetShowCar()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})