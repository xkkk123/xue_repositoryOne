// pages/home/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperData:[
      {
        id:0,
        title:"第一张图片",
        src:"https://act-webstatic.mihoyo.com/upload/contentweb/bh3/949eb3a596b9e62a89d6fe3285060d87_6211551588533218452.png"
      },
      {
        id:1,
        title:"第二张图片",
        src:"https://act-webstatic.mihoyo.com/upload/contentweb/bh3/cc417f2a0c624a360139f08d53e126a4_2833857869198737967.png"
      },
      {
        id:2,
        title:"第三张图片",
        src:"https://act-webstatic.mihoyo.com/upload/contentweb/bh3/52553b2d575800829cca106fa3e2f3df_6020396235392641864.png"
      }
    ],
    article:[],
    currentIndex:0,
    token:'',
    value:'',
    show:true,
    limit:{
      page:1,
      line:10,
    },
    index:-1
  },
  onClickFurit(){
    wx.navigateTo({
      url: '/pages/furit/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    this.setData({
      token:token
    })
    this.getArticle()
  },
  getArticle(){
    wx.request({
      url: 'http://192.168.1.6:8082/getArticle',
      method:'GET',
      data:this.data.limit,
      success:(res)=>{
          this.setData({
            article:res.data.data
          })
      }
    })
  },
  handleChange(e){
    this.setData({
      currentIndex:e.detail.current
    })
  },
  favorites(e){
    const index=e.currentTarget.dataset.index
    const articleid=e.currentTarget.dataset.id
    const favorite=e.currentTarget.dataset.favorite
    this.setData({
        ['article['+index+'].type']:!this.data.article[index].type
    })
        
    wx.request({
        url: 'http://localhost:8082/api/setLike',
        method:'GET',
        header:{'Authorization':this.data.token},
        data:{articleid:this.data.article[index].id,rep_userid:this.data.article[index].user.id,commentid:0,articleid:articleid,favorite:favorite},
        success:(res)=>{
          console.log(res);
          this.setData({
            ['article['+index+'].favorite']:res.data.data.favorite
          })
        }
    })
  },
  onClicknutrition(){
    wx.navigateTo({
      url: '/pages/nutrition/index',
    })
  },
  onJumpPage(e){
    const index=e.currentTarget.dataset.index
    const article= JSON.stringify(this.data.article[index])
    wx.navigateTo({
      url: '/pages/content/index?article='+article,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  shareNull(e){
    console.log(e.currentTarget.dataset.index);
    this.setData({
      index:e.currentTarget.dataset.index
    })
  },
  onShareAppMessage(res) {
      const { article,index }=this.data
      //参数
      return{
        title:article[index].title,
        path:"/pages/content/index?article="+JSON.stringify(article), 
        imageUrl:article[index].image[0].image
      }
  }
})