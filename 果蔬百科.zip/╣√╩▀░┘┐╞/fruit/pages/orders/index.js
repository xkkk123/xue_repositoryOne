// pages/orders/index.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:false,
    dialogShow:false,
    token:'',
    address:[],
    addressNow:{},
    orders:[],
    price:0,
    active:-1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })

    this.onGetOrders()
  },
  showPopup() {
    this.setData({ show: true });
  },

  onClose() {
    this.setData({ 
      show: false,
      dialogShow:false
    });
  },
  onSubmit(){
    wx.request({
      url: 'http://localhost:8082/api/submitOrder',
      method:'GET',
      data:{price:this.data.price},
      header:{'Authorization':this.data.token},
      success:(res)=>{
        if (res.data.data==="fail") {
          this.setData({
            dialogShow:true
          })
        }
      }
    })
  },
  onGetOrders(){
    wx.request({
      url: 'http://localhost:8082/api/getOrders',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        this.setData({
          address:res.data.data.address,
          orders:res.data.data.orders
        })
        this.getData()
      }
    })
  },
  getData(){
    const {orders,address}=this.data;
    let price=0;
    for (let i = 0; i < orders.length; i++) {
      price+= orders[i].price*1*orders[i].number
    }
    for (let i = 0; i < address.length; i++) {
      if (address[i].defaults===1) {
        this.setData({
            active:i
        })
        break;
      }
    }
    this.setData({
      price:price
    })


  },
  setAddress(e){
    console.log();
    this.setData({
      active:e.currentTarget.dataset.index
    })
    this.onClose()
  },
  onEditAddress(e){
    wx.navigateTo({
      url: '/pages/address/index?id='+e.currentTarget.dataset.id,
    })
  },
  onConfirm(){
      wx.navigateTo({
        url: '/pages/add/index',
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})