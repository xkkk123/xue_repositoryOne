// pages/community/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    questionsNavArr:['最新','0回答','高分悬赏','已解决'],
    activeIdx:0,
    query:{
      page:1,
      line:10
    },
    article:[]
  },
  onJumpPage(){
      wx.navigateTo({
        url: '/pages/content/index',
      })
  },
  onActive(e){
      this.setData({
        activeIdx:e.target.dataset.index
      })
  },
  onChange(event) {
    switch (event.detail.title) {
      case '悬赏问答':
        this.onGetReward(event.detail.title)
        break;
      default:
          console.log(1);
        break;
    }
  },
  onGetReward(category){
    console.log(category);
    wx.request({
      url: 'http://localhost:8082/getReward',
      method:'GET',
      data:{query:this.data.query,category},
      success:(res)=>{
        console.log(res);
        this.setData({
          article:res.data.data
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})