// pages/register/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    username:'',
    password:'',
    avatarUrl:'',
    reUsername:''
  },
  onChooseAvatar(e){
    this.setData({
      avatarUrl:e.detail.avatarUrl
    })
    this.upload()
    console.log(1);
  },
  upload(){
    const _this=this;
    wx.uploadFile({
      filePath: this.data.avatarUrl,
      name: 'avatarUrl',
      url: 'http://localhost:8082/uploads',
      header:{
        'content-type':'multipart/form-data'
      },
      success:(res)=>{
        let data=JSON.parse(res.data)
        _this.setData({
          avatarUrl:data.path
        })
      }
    })
  },
  onRegister(){
      wx.request({
        url: 'http://localhost:8082/register',
        method:'POST',
        data:{
          'username':this.data.username,
          'password':this.data.password,
          'avatarUrl':this.data.avatarUrl
        },
        success:(res)=>{
          wx.showToast({
            title: '注册成功',
          })
          setTimeout(()=>{
              wx.redirectTo({
                url: '/pages/login/index',
              })
          },1000)
        }
      })
  },
  onChange(e){
    // console.log(e);
    // console.log(e);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})