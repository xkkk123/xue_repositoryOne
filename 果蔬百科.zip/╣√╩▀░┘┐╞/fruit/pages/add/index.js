// pages/add/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    addBoxArr:[30,50,100,200,300],
    active:-1,
    price:0,
    token:'',
    src:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
    
  },
  onClickAddBox(e){
    console.log(e);
    this.setData({
      active:e.currentTarget.dataset.index,
      price:e.currentTarget.dataset.price
    })
  },
  onAddPoints(){
    wx.request({
      url: 'http://localhost:8082/api/setPoints',
      method:'POST',
      data:{orderId:'xudas14'},
      header:{'Authorization':this.data.token,'content-type':'application/x-www-form-urlencoded'},
      success:(res)=>{
        console.log(res);
        this.setData({
          src:res.data.data
        })
        wx.setStorageSync('src', res.data.data)
        setTimeout(()=>{
          wx.navigateTo({
            url: '/pages/a/index',
          })
        },500)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})