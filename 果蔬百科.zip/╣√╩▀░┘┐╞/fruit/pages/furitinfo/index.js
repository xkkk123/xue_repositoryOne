// pages/furitinfo/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      token:'',
      selectTextShow:'',
      selectShow:false,
      buttonType:'',
      number:1,
      appraise:{},
      mallInfo:{},
      mallType:{},
      total:'',
      active:-1,
      query:{
        id:0,
        page:1,
        line:5
      }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const id=options.mallid
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      'query.id':id,
      token:token
    })
    wx.request({
      url: 'http://localhost:8082/getAppraise',
      method:'GET',
      data:this.data.query,
      success:(res)=>{
        this.setData({
          appraise:res.data.data.result[0],
          total:res.data.data.total
        })
      }
    })
    this.onGetMallInfo()
  },
  onClickSelect(){
    this.setData({
      selectShow:true
    })
  },
  onClose(){
    this.setData({ 
      selectShow: false,
      buttonType:''
    });
  },
  onClickIcon(e) {
      wx.navigateTo({
        url: '/pages/shopping/index',
      })
  },

  onClickButton(e) {
      this.setData({
        selectShow:true,
        buttonType:e.currentTarget.dataset.type
      })
  },
  onGetMallInfo(){
    wx.request({
      url: 'http://localhost:8082/getMallInfo',
      method:'GET',
      data:{id:this.data.query.id},
      success:(res)=>{
        this.setData({
          mallInfo:res.data.data[0],
          mallType:res.data.data[0].types[0]
        })
      }
    })
  },
  onActive(e){
    let index=e.currentTarget.dataset.index;
    const {mallInfo}=this.data
    this.setData({
      active:index,
      mallType:mallInfo.types[index],
      selectTextShow:mallInfo.types[index].type
    })
  },
  onChange(e){
    this.setData({
      number:e.detail
    })
  },
  onClickShopCar(){
    if (this.data.active===-1) {
        wx.showToast({
          title: '请选择商品',
          icon:'error'
        })
    }else{
        const shopCar=this.onGetOrderData()
        wx.request({
          url: 'http://localhost:8082/api/insertShopCar',
          method:'POST',
          header:{'Authorization':this.data.token},
          data:shopCar,
          success:(res)=>{
            console.log(res);
          }
        })
    }
  },
  onClickBuy(){
    if (this.data.active===-1) {
      wx.showToast({
        title: '请选择商品',
        icon:'error'
      })
    }else{
     const order= this.onGetOrderData()
      wx.request({
        url: 'http://localhost:8082/api/insertOrders',
        method:'POST',
        header:{'Authorization':this.data.token},
        data:order,
        success:(res)=>{
          wx.navigateTo({
            url: '/pages/orders/index',
          })
        }
      })
    }
  },
  onGetOrderData(){
    const shopCar={}
    const {mallType}=this.data
    shopCar.goods_type=mallType.type
    shopCar.price=mallType.points
    shopCar.goods_image=mallType.image
    shopCar.number=this.data.number
    shopCar.mallid=this.data.mallInfo.id
    shopCar.goods_name=this.data.mallInfo.name
    shopCar.category=this.data.mallInfo.category
    return shopCar
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})