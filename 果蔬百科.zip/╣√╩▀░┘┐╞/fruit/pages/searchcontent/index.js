// pages/searchcontent/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'',
    value:'',
    article:[],
    user:[],
    query:{
      page:1,
      line:10,
    },
    type:'关注'
  },
  onFocus(){
    wx.navigateTo({
      url: '/pages/search/index?search='+this.data.value,
    })
  },
  onChange(event) {
    console.log(event.detail.title);
    switch (event.detail.title) {
      case '文章':
        this.onGetSearchArticle()
        break;
      case '植物':
        this.onGetSearchBaike()
        break;
      case '用户':
        this.onGetSearchUser()
        break;
      default:
        break;
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    if (token!==undefined) {
      token='Bearer '+token
      this.setData({
        token:token
      })
    }

    this.setData({
      value:options.search
    })
    this.onGetSearchArticle()
  },
  onGetSearchArticle(){
    wx.request({
        url: 'http://localhost:8082/getSearchArticle',
        method:'GET',
        data:{query:this.data.query,value:this.data.value},
        success:(res)=>{
          console.log(res);
          this.setData({
            article:res.data.data
          })
        }
    })
  },
  onGetSearchBaike(){
    wx.request({
        url: 'http://localhost:8082/getSearchBaike',
        method:'GET',
        data:{query:this.data.query,value:this.data.value},
        success:(res)=>{
          console.log(res);
          this.setData({
            article:res.data.data
          })
        }
    })
  },
  onGetSearchUser(){
    console.log(this.data.token);
    if (this.data.token==='Bearer ') {
      wx.request({
        url: 'http://localhost:8082/getSearchUser',
        method:'GET',
        data:{query:this.data.query,value:this.data.value},
        success:(res)=>{
          this.setData({
            user:res.data.data
          })
        }
      })
    }else{
      wx.request({
        url: 'http://localhost:8082/api/getSearchTokenUser',
        method:'GET',
        header:{'Authorization':this.data.token},
        data:{query:this.data.query,value:this.data.value},
        success:(res)=>{
          this.setData({
            user:res.data.data
          })
        }
      })
    }

  },
  onClickButton(e){
    switch (e.currentTarget.dataset.type) {
      case '已关注':
        this.deleteConcern(e.currentTarget.dataset.userid)
        break;
      case '不能对自己操作':
          wx.showToast({
            title: '不能对自己进行操作',
            icon:'error'
          })
          break;
      default:
        this.insertConcern(e.currentTarget.dataset.userid)
        break;
    }
  },
  deleteConcern(id){
    wx.request({
      url: 'http://localhost:8082/api/deleteConcern',
      method:'GET',
      header:{'Authorization':this.data.token},
      data:{rep_userid:id},
      success:(res)=>{
        console.log(res);
      }
    })
  },
  insertConcern(id){
    wx.request({
      url: 'http://localhost:8082/api/setConcern',
      method:'GET',
      header:{'Authorization':this.data.token},
      data:{rep_userid:id},
      success:(res)=>{
        console.log(res);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})