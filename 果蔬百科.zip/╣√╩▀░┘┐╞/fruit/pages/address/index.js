// pages/address/index.js
// const options = [
//   {
//     name: '浙江省',
//     area_id: '330000',
//     children: [{ name: '杭州市', area_id: '330100', children: [{ name: '杭州市', area_id: '330100' }]}],
//   },
//   {
//     name: '江苏省',
//     area_id: '320000',
//     children: [{ name: '南京市', value: '320100' }],
//   },
// ];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'',
    checked:false,
    user:'',
    phone:'',
    detail_area:'',
    fieldNames: {
      text: 'name',
      value: 'area_id',
      children: 'children',
    },
    options:[], 
    fieldValue: '',
    cascaderValue: '',
    show:false,
    disabled:false,
    id:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
    if (options.id!==undefined) {
      this.setData({
        id:options.id
      }) 
      this.onGetAddress()
    }
    this.onGetArea()
  },
  onGetAddress(){
    wx.request({
      url: 'http://localhost:8082/api/getAddress',
      method:'GET',
      header:{'Authorization':this.data.token},
      data:{id:this.data.id},
      success:(res)=>{
        const address=res.data.data
        console.log(address);
        const checked=address.defaults===1?true:false
        this.setData({
          user:address.username,
          phone:address.phone,
          detail_area:address.detail_area,
          fieldValue:address.area,
          checked:checked
        })
      }
    })
  },
  onGetArea(){
    wx.request({
      url: 'http://localhost:8082/api/getArea',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        this.setData({
          options:res.data.data
        })
      } 
    })
    
  },
  onChange({ detail }) {
    // 需要手动对 checked 状态进行更新
    this.setData({ checked: detail });
  },
  onClick() {
    this.setData({
      show: true,
    });
  },

  onClose() {
    this.setData({
      show: false,
    });
  },
  onFinish(e) {
    console.log(e.detail);
    const { selectedOptions, value } = e.detail;
    const fieldValue = selectedOptions
        .map((option) => option.text || option.name)
        .join('/');
    this.setData({
      fieldValue,
      cascaderValue: value,
      show:false
    })
  },
  onGetEmpty(){
    const {user,phone,detail_area,fieldValue}=this.data
    const disabled=user===''&&phone===''&&detail_area===''&&fieldValue===''?true:false
    this.setData({
      disabled:disabled
    })
    return disabled
  },
  onClickSubmit(){
      if (this.data.id==='') {
        this.onSetAddress()
      }else{
        this.onUpdataAddress()
      }
  },
  onUpdataAddress(){
    const {user,phone,detail_area,fieldValue,checked,id}=this.data
    const address={}
    address.username=user
    address.phone=phone
    address.area=fieldValue
    address.detailArea=detail_area
    address.defaults=checked?0:1
    address.id=id*1
    wx.request({
      url: 'http://localhost:8082/api/updataAddress',
      method:'PUT',
      header:{'Authorization':this.data.token},
      data:address,
      success:(res)=>{
        wx.navigateTo({
          url: '/pages/orders/index',
        })
      }
    })
  },
  onSetAddress(){
    if (this.onGetEmpty()) {
        wx.showToast({
          title: '信息不全，请输入',
        })
    }else{
      const {user,phone,detail_area,fieldValue,checked}=this.data
      const address={}
      address.username=user
      address.phone=phone
      address.area=fieldValue
      address.detail_area=detail_area
      address.defaults=checked===false?0:1
      wx.request({
        url: 'http://localhost:8082/api/setAddress',
        method:'POST',
        header:{'Authorization':this.data.token},
        data:address,
        success:(res)=>{
          wx.navigateTo({
            url: '/pages/orders/index',
          })
        }
      })
    }

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})