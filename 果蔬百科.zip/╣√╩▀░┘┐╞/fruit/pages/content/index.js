// pages/content/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:true,
    showPopup: false,
    hidden:'hidden',
    btnHidden:'block',
    height:'1200rpx',
    sheetShow:false,
    value:'',
    imageArray:[],
    newImageArray:[],
    article:{},
    comments:[],
    concernText:"关注",
    index:-1,
    comment:{},
    levelComment:[]
  },
  onClickAll(){
    this.setData({
      hidden:'none',
      btnHidden:'none',
      height:''
    })
  },
  onClickSheet(){
    this.setData({
      sheetShow:true
    })
  },
  onClose() {
    this.setData({ 
      sheetShow: false,
      showPopup:false
    });
  },
  onChange(){
    console.log(1);
  },
  onUpload(){
    let that=this;
    wx.chooseMedia({
      count: 9,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      camera: 'back',
      success(res) {
        const arr=[]
        for (let i = 0; i < res.tempFiles.length; i++) {
          arr.push(res.tempFiles[i].tempFilePath)
        }
        that.setData({
            imageArray:arr
        })
        that.upload()
      }
    })
    
  },
  upload(){
    const _this=this;
    const uploadImageArr=[]
    for (let i = 0; i < this.data.imageArray.length; i++) {
      wx.uploadFile({
        filePath: this.data.imageArray[i],
        name: 'avatarUrl',
        url: 'http://localhost:8082/uploads',
        header:{
          'content-type':'multipart/form-data'
        },
        success:(res)=>{
          let data=JSON.parse(res.data)
          uploadImageArr.push(data.path)
          // console.log(uploadImageArr);
          _this.setData({
            imageArray:uploadImageArr
          })
          console.log(this.data.imageArray);
        }
      })
    }
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const article= JSON.parse(options.article)
    this.setData({
      article:article
    })
    this.onGetComments()
    this.onjudgmentConcern()
  },
  onGetComments(){    
    let token=wx.getStorageSync('token')
    token='Bearer '+token
      wx.request({
        url: 'http://localhost:8082/getComments',
        method:'GET',
        header:{'Authorization':token},
        data:{
          id:this.data.article.id
        },
        success:(res)=>{
          this.setData({
            comments:res.data.data
          })
        }
    })
  },
  onConcern(e){
    const rep_userid=e.currentTarget.dataset.userid
    if (e.currentTarget.dataset.concerntext==="已关注") {
      this.onCancel(rep_userid)
      this.setData({
        concernText:"关注"
      })
    }else{
      this.onSetConcern(rep_userid)
      this.setData({
        concernText:"已关注"
      })
    }
  },
  onSetConcern(rep_userid){
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    wx.request({
      url: 'http://localhost:8082/api/setConcern',
      method:'GET',
      header:{'Authorization':token},
      data:{rep_userid:rep_userid},
      success:(res)=>{
        // console.log(res);
      }
    })
  },
  onCancel(rep_userid){
    console.log(rep_userid);
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    wx.request({
      url: 'http://localhost:8082/api/deleteConcern',
      method:'GET',
      header:{'Authorization':token},
      data:{rep_userid:rep_userid},
      success:(res)=>{
        // console.log(res);
      }
    })
  },
  onjudgmentConcern(){
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    const rep_userid=this.data.article.user.id
    wx.request({
      url: 'http://localhost:8082/api/judgmentConcern',
      method:'GET',
      header:{'Authorization':token},
      data:{rep_userid:rep_userid},
      success:(res)=>{
        this.setData({
          concernText:res.data.data
        })
      }
    })
  },
  onClickReply(e){
    this.setData({
      sheetShow:true,
      index:e.currentTarget.dataset.index
    })
  },
  onReply(){
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setComment()
    wx.request({
      url: 'http://localhost:8082/api/setReply',
      method:'POST',
      header:{'Authorization':token},
      data:this.data.comment,
      success:(res)=>{
        console.log(res);
      }
    })
  },
  setComment(){
    const index=this.data.index
    console.log(this.data.comments[index]);
    if (index>=0) {
      const level=this.data.comments[index].level+1>=3?3:2   
      this.setData({
      'comment.content':this.data.value,
      'comment.articleid':this.data.comments[index].articleid,
      'comment.rep_userid':this.data.comments[index].userid,
      'comment.commentid':this.data.comments[index].id,
      'comment.image':this.data.imageArray,
      'comment.level':level
      })
    }else{
      const level=1   
      this.setData({
      'comment.content':this.data.value,
      'comment.articleid':this.data.article.id,
      'comment.rep_userid':null,
      'comment.commentid':null,
      'comment.image':this.data.imageArray,
      'comment.level':level
      })
    }
  },
  showPopup(e) {
    console.log(e.currentTarget.dataset.id);
    this.setData({ showPopup: true });
    this.getReplyLevel(e.currentTarget.dataset.id)
  },
  onClosePopup(){
    this.setData({ 
      showPopup:false
    });
  },
  getReplyLevel(id){
    console.log(id);
    wx.request({
      url: 'http://localhost:8082/getReplyLevel',
      method:'GET',
      data:{commentid:id},
      success:(res)=>{
        console.log(res);
        this.setData({
          levelComment:res.data.data
        })
      }
    })
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})