// pages/mine/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user:{},
    show:false,
    loginShow:true,
    dialogShow:false
  },
  onLogin(){
    wx.navigateTo({
      url: '/pages/login/index',
    })
  },
  onClickPublish(){
      this.setData({
        show:true
      })
      wx.hideTabBar()
  },
  onClose() {
    this.setData({ show: false });
    setTimeout(()=>{
        wx.showTabBar()
    },300)

  },
  onCloseDia(){
    this.setData({
      dialogShow:false
    })
  },
  onConfirm(){
    wx.navigateTo({
      url: '/pages/login/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    if (token!=='') {
      token='Bearer '+token;
      this.setData({
        loginShow:false
      })
      
      wx.request({
        url: 'http://localhost:8082/api/getUser',
        method:'GET',
        header:{'Authorization':token},
        success:(res)=>{
          console.log(res.data.data);
          this.setData({
            user:res.data.data[0]
          })
        }
      })
    }
  },
  onClickTsan(){
    if (this.data.loginShow===true) {
      console.log(2);
      this.setData({
        dialogShow:true
      })
    }else{
      console.log(1);
      wx.navigateTo({
        url: '/pages/tsan/index?',
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
  }
})