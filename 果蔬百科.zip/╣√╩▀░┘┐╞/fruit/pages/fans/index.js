// pages/fans/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fans:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    wx.request({
      url: 'http://localhost:8082/api/getFans',
      method:'GET',
      header:{'Authorization':token},
      success:(res)=>{
          this.setData({
            fans:res.data.data
          })
      }
    })
  },
  onCancel(e){
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    const rep_userid=e.currentTarget.dataset.userid;
    const state=e.currentTarget.dataset.state==="回关"?"已互粉":"回关"
    wx.request({
      url: 'http://localhost:8082/api/updataFans',
      method:'GET',
      header:{'Authorization':token},
      data:{rep_userid:rep_userid,state:state},
      success:(res)=>{
        setTimeout(()=>{
          wx.showToast({
            title: '已关注',
          })
          this.onLoad()
        },1000)
        
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})