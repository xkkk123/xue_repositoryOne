// pages/history/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:true,
    favorite:false,
    token:'',
    histroyData:[]
  },
  onClick(e){
    console.log(e.detail.title);
    if (e.detail.title==='社区') {
        this.onGetHistroy()
    }else if (e.detail.title==='文章') {
      this.onGetEssay()
    }
  },
  favorites:function(){
    this.setData({
      favorite:!this.data.favorite
    })
},
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
    this.onGetEssay()
  },
  onGetEssay(){
    wx.request({
      url: 'http://localhost:8082/api/getArticleHistory',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        console.log(res);
        this.setData({
          histroyData:res.data.data
        })
      }
    })
  },
  onGetHistroy(){
    wx.request({
      url: 'http://localhost:8082/api/getArticle',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        console.log(res);
        this.setData({
          histroyData:res.data.data
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})