// pages/dynamic/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title:'',
    content:'',
    imageArray:[],
    tempArray:[],
    token:''
  },
  onUpload(){
    let that=this;
    const imaArr=[];
    wx.chooseMedia({
      count: 9,
      mediaType: ['image'],
      sourceType: ['album','camera'],
      camera: 'back',
      success(res) {
        for (let i = 0; i < res.tempFiles.length; i++) {
            imaArr.push(res.tempFiles[i].tempFilePath)
        }
        that.setData({
            tempArray:imaArr
        })
        that.upload()
      }
    })
  },
  deleteImage(){
    
  },
  setDynamic(){
    const dynamic={}
    dynamic.title=this.data.title
    dynamic.content=this.data.content
    dynamic.image=this.data.imageArray
    wx.request({
      url: 'http://localhost:8082/api/setDynamic',
      method:'POST',
      data:dynamic,
      header:{'Authorization':this.data.token},
      success:(res)=>{

          if (res.data.data==='success') {
              wx.showToast({
                title: '发布成功',
              })
              setTimeout(()=>{
                this.setData({
                    title:'',
                    content:'',
                    imageArray:''
                })
              })

          }
      }
    })
  },
  upload(){
    const _this=this;
    const uploadImageArr=this.data.imageArray
    for (let i = 0; i < this.data.tempArray.length; i++) {
      wx.uploadFile({
        filePath: this.data.tempArray[i],
        name: 'avatarUrl',
        url: 'http://localhost:8082/uploads',
        header:{
          'content-type':'multipart/form-data'
        },
        success:(res)=>{
          let data=JSON.parse(res.data)
          uploadImageArr.push(data.path)
          _this.setData({
            imageArray:uploadImageArr
          })
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})