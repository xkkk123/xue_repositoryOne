// pages/concern/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    concern:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    wx.request({
      url: 'http://localhost:8082/api/getConcern',
      method:'GET',
      header:{'Authorization':token},
      success:(res)=>{
        console.log(res);
          this.setData({
            concern:res.data.data
          })
      }
    })
  },
  onCancel(e){
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    const rep_userid=e.currentTarget.dataset.userid
    wx.request({
      url: 'http://localhost:8082/api/deleteConcern',
      method:'GET',
      header:{'Authorization':token},
      data:{rep_userid:rep_userid},
      success:(res)=>{
        console.log(res);
        setTimeout(()=>{
          wx.showToast({
            title: '已取消关注',
          })
          this.onLoad()
        },1000)
        
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})