// pages/nutrition/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active:{
      furitActive:{
        mainActiveIndex: 0,
        activeId: [],
        max: 9,
      },
      vegetableActive:{
        mainActiveIndex: 0,
        activeId: [],
        max: 2,
      }
    },
    furitItems:[
      {
        // 导航名称
        text: '水果',
        // 导航名称右上角徽标，1.5.0 版本开始支持
        badge: '',
        // 是否在导航名称右上角显示小红点，1.5.0 版本开始支持
        dot: false,
        // 禁用选项
        disabled: false,
        // 该导航下所有的可选项
        children: [],
      },
    ],
    vegetableItems:[
      {
        // 导航名称
        text: '蔬菜',
        // 导航名称右上角徽标，1.5.0 版本开始支持
        badge: '',
        // 是否在导航名称右上角显示小红点，1.5.0 版本开始支持
        dot: false,
        // 禁用选项
        disabled: false,
        // 该导航下所有的可选项
        children: [],
      },
    ],
    gradientColor: {
      '0%': '#D53624',
      '100%': '#00C9A7',
    },
    actions: [],
    furitArr:[],
    vegetableArr:[],
    suggest:[],
    value:0,
    show:false,
    furitShow:false,
    vegetableShow:false,
    disease:{},
    token:''
  },
  onClickFurit(){
    const {disease}=this.data
    if (JSON.stringify(disease)==="{}") {
      wx.showToast({
        title: '请选择病例',
      })
    }else{
      this.setData({
        furitShow:true
      })
    }
  },
  onClickVegetable(){
    const {disease}=this.data
    if (JSON.stringify(disease)==="{}") {
      wx.showToast({
        title: '请选择病例',
      })
    }else{
      this.setData({
        vegetableShow:true
      })
    }
  },
  onClickSelect(){
    this.setData({
      show:true,
    })
  },
  onClose() {
    this.setData({
       show: false,
       furitShow:false,
       vegetableShow:false
      });
  },
  onChange(e) {
    if (e.currentTarget.dataset.furitindex!==undefined) {
        this.setData({
          ['furitArr['+e.currentTarget.dataset.furitindex+'].number']:e.detail
        })
    }
    if(e.currentTarget.dataset.vegetableindex!==undefined){
      console.log('vegetableindex');
      this.setData({
        ['vegetableArr['+e.currentTarget.dataset.vegetableindex+'].number']:e.detail
      })
    }
    this.onGetValue()
  },
  onGetValue(){
    const { disease,furitArr,vegetableArr}=this.data;
    let value=0;

    if (JSON.stringify(disease)!=="{}") {
      for (let i = 0; i < furitArr.length; i++) {
        if (disease.lack.type===furitArr[i].type) {
          console.log(furitArr[i].content);
          value+=(furitArr[i].content/disease.lack.num*1)*furitArr[i].number*100
        }
      }
      for (let j = 0; j < vegetableArr.length; j++) {
        if (disease.lack.type===vegetableArr[j].type) {
          value+=(vegetableArr[j].content/disease.lack.num*1)*vegetableArr[j].number*100
        }
      }
    }else{
      console.log(1);
    }
    value=Math.round(value)
    this.setData({
      value:value
    })
  },
  onSelect(e) {
    this.setData({
      disease:e.detail
    })
    wx.request({
      url: 'http://localhost:8082/api/getSuggest',
      method:'GET',
      header:{'Authorization':this.data.token},
      data:e.detail.lack,
      success:(res)=>{
        this.setData({
          suggest:res.data.data
        })
      }
    })
  },
  onClickItem({ detail = {} }) {
      const activeId = this.data.active.furitActive.activeId;
      const {furitArr}=this.data
      const index = activeId.indexOf(detail.id);
      if (index > -1) {
        activeId.splice(index, 1);
        furitArr.splice(index,1)
        
      } else {
        activeId.push(detail.id);
        furitArr.push(detail)
        furitArr[furitArr.length-1].number=1;
      }
      this.setData({
        'active.furitActive.activeId':activeId,
        furitArr
      });
      this.onGetValue()
  },
  onClickVegetableItem({ detail = {} }) {
      const activeId = this.data.active.vegetableActive.activeId;
      const { vegetableArr }=this.data
      const index = activeId.indexOf(detail.id);
      if (index > -1) {
        activeId.splice(index, 1);
        vegetableArr.splice(index,1)
      } else {
        activeId.push(detail.id);
        vegetableArr.push(detail)
        vegetableArr[vegetableArr.length-1].number=1;
      }
      this.setData({
        'active.vegetableActive.activeId':activeId,
        vegetableArr
        });
        this.onGetValue()
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token
    this.setData({
      token:token
    })
    this.onGetDisease()
    this.onGetFurit()
    this.onGetVegetable()
  },
  onGetDisease(){
    wx.request({
      url: 'http://localhost:8082/getDisease',
      method:'GET',
      success:(res)=>{

        this.setData({
          actions:res.data.data
        })
        // console.log(this.data.actions);
      }
    })
  },

  onGetFurit(){
    wx.request({
      url: 'http://localhost:8082/getBaike',
      method:'GET',
      data:{kind:'水果'},
      success:(res)=>{
        this.setData({
          ['furitItems[0].children']:res.data.data
        })
      }
    })
  },

  onGetVegetable(){
    wx.request({
      url: 'http://localhost:8082/getBaike',
      method:'GET',
      data:{kind:'蔬菜'},
      success:(res)=>{
        // console.log(res);
        this.setData({
          ['vegetableItems[0].children']:res.data.data
        })
        console.log(this.data.vegetableItems[0].children);
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})