// pages/notice/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    reply:[],
    token:'',
    dialogShow:false,
    userid:0,
    articleid:0,
    points:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token')
    token='Bearer '+token;
    this.setData({
      token:token
    })
    this.getReply()
  },
  getReply(){
    wx.request({
      url: 'http://localhost:8082/api/getReply',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        this.setData({
          reply:res.data.data
        })
      }
    })
  },
  getAnswer(){
    wx.request({
      url: 'http://localhost:8082/api/getAnswer',
      method:'GET',
      header:{'Authorization':this.data.token},
      success:(res)=>{
        this.setData({
          reply:res.data.data
        })
        console.log(this.data.reply);
      }
    })
  },
  onAnswer(e){
      this.setData({
        dialogShow:true,
        userid:e.currentTarget.dataset.userid,
        articleid:e.currentTarget.dataset.articleid,
        points:e.currentTarget.dataset.points
      })
  },
  onConfirm(){
    wx.request({
      url: 'http://localhost:8082/api/setAnswer',
      method:'POST',
      header:{'Authorization':this.data.token},
      data:{userid:this.data.userid,articleid:this.data.articleid,points:this.data.points},
      success:(res)=>{
          console.log(res);
          if (res.data.data==='success') {
              wx.showToast({
                title: '结算成功',
              })
              this.getAnswer()
          }
      }
    })
  },
  onClose() {
    this.setData({ 
      dialogShow:false
    });
  },
  onChange(event) {
    switch (event.detail.title) {
      case '回答':
          this.getAnswer()
        break;
      case '回复我的':
          this.getReply()
        break;
      default:
        break;
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})