// pages/coinsget/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'',
    task:[
      {
        title:"浏览3个帖子",
        points:30,
        status:0,
        number:3
      },
      {
        title:"点赞一篇文章",
        points:50,
        status:0,
        number:1
      },
      {
        title:"发表一个评论",
        points:50,
        status:0,
        number:1
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // const dateValue= wx.getStorageSync('dateValue')
    // let token=wx.getStorageSync('token')
    // token='Bearer '+token
    // this.setData({
    //   token:token
    // })
    // const date=new Date().getDate()

  },
  onGetTask(){
    wx.request({
      url: 'http://localhost:8082/api/getTask',
      method:'GET',
      header:{'Authorization':token},
      success:(res)=>{
        console.log(res);
      }
      
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})