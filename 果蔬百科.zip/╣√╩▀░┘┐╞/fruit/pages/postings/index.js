// pages/postings/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    token:'',
    title:'',
    content:'',
    categoryText:"选择板块",
    pointsText:'选择悬赏积分',
    showCategory:false,
    showPoints:false,
    imageArray:[],
    tempImage:[],
    Category:['悬赏问答','爱花展示','养花日记','悬赏问答','爱花展示','养花日记','悬赏问答','爱花展示','养花日记'],
    pointsArr:[50,100,150,200,300],
    minePoints:200,
    setPoints:'',
    placeholder:'填写标题(6~30字之内，必填)'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onChooseUpload(){
    let that=this;
    const tempArr=[];
    wx.chooseMedia({
      count: 9,
      mediaType: ['image'],
      sourceType: ['album'],
      camera: 'back',
      success(res) {
        for (let i = 0; i < res.tempFiles.length; i++) {
            tempArr.push(res.tempFiles[i].tempFilePath)
        }
        that.setData({
            tempImage:tempArr
        })
        that.upload()
      }
    })
  },
  onCameraUpload(){
    let that=this;
    const imaArr=this.data.imageArray;
    wx.chooseMedia({
      count: 9,
      mediaType: ['image'],
      sourceType: ['camera'],
      camera: 'back',
      success(res) {
        for (let i = 0; i < res.tempFiles.length; i++) {
          imaArr.push({image:res.tempFiles[i].tempFilePath,content:''})
        }
        that.setData({
            imageArray:imaArr
        })
      }
    })
  },
  onSetContent(e){
    const index=e.currentTarget.dataset.index
    const imgArr=this.data.imageArray
    imgArr[index].content=e.detail.value;
    this.setData({
      imageArray:imgArr
    })
  },
  upload(){
    const _this=this;
    const uploadImageArr=[]
    const imgArr=this.data.imageArray
    for (let i = 0; i < this.data.tempImage.length; i++) {
      wx.uploadFile({
        filePath: this.data.tempImage[i],
        name: 'avatarUrl',
        url: 'http://localhost:8082/uploads',
        header:{
          'content-type':'multipart/form-data'
        },
        success:(res)=>{
          let data=JSON.parse(res.data)
          uploadImageArr.push(data.path)
          _this.setData({
            tempImage:uploadImageArr
          })
          imgArr.push({image:_this.data.tempImage[i],content:''})
          _this.setData({
            imageArray:imgArr
          })
        }
      })
    }
    
  },
  onPublish(){
    const article={};
    article.title=this.data.title;
    article.content=this.data.content;
    article.image=this.data.imageArray;
    article.category=this.data.categoryText;
    article.points=this.data.setPoints;

    wx.request({
      url: 'http://localhost:8082/api/setArticle',
      method:'POST',
      header:{'Authorization':this.data.token},
      data:article,
      success:(res)=>{

        if (res.data.data==='success') {
          setTimeout(()=>{          
              this.setData({
                title:'',
                content:'',
                imageArray:[],
                categoryText:"选择板块"
              })
              wx.showToast({
                title: '发布成功',
              })
          },500)
        }
      }
    })
  },
  onShowCategory(){
    this.setData({
      showCategory:true
    })
  },
  onChooseCategory(e){
    const item=e.currentTarget.dataset.item;
    this.setData({
      categoryText:item
    })
    console.log(this.data.categoryText);
    this.onClose()
  },
  onShowPoints(e){
    this.setData({
      showPoints:true
    })
  },
  onChoosePoints(e){
    this.setData({
      setPoints:e.currentTarget.dataset.points,
      pointsText:'已选择 '+e.currentTarget.dataset.points+' 积分',
      showPoints:false
    })
  },
  onClose(){
    this.setData({
      showCategory:false,
      showPoints:false
    })
  },
  onGetPoints(){
      wx.request({
        url: 'http://localhost:8082/api/getMinePoints',
        method:'GET',
        header:{'Authorization':this.data.token},
        success:(res)=>{
          this.setData({
            minePoints:res.data.data.points
          })
        }
      })
  },
  onLoad(options) {
      let token=wx.getStorageSync('token')
      token='Bearer '+token;
      if (options.type==='悬赏问答') {
          this.setData({
            token:token,
            categoryText:options.type,
            placeholder:'请用“果蔬名+症状”的组合提问'
          })
          this.onGetPoints()
      }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})