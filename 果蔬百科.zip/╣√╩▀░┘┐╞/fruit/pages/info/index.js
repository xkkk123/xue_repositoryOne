// pages/info/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      sex:true,
      imgSize:false,
      show:true,
      user:{},
      dynamic:[],
      limit:{
        page:1,
        line:5,
      }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    let token=wx.getStorageSync('token');
    token='Bearer '+token;
    wx.request({
      url: 'http://localhost:8082/api/getUser',
      method:'GET',
      header:{'Authorization':token},
      success:(res)=>{
        this.setData({
          user:res.data.data[0]
        })
      }
    })
    this.onLoadDynamic()
  },
  onLoadDynamic(){
    let token=wx.getStorageSync('token');
    token='Bearer '+token;
    let dynam =this.data.dynamic
    wx.request({
      url: 'http://localhost:8082/api/loadDynamic',
      method:"GET",
      header:{'Authorization':token},
      data:this.data.limit,
      success:(res)=>{
          console.log(res.data.data);
          if (res.data.data.length!==0) {
            dynam=dynam.concat(res.data.data)
            this.setData({
                dynamic:dynam
            })
          }else{
            this.setData({
              show:false
            })
          }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if (this.data.show!==false) {
      this.setData({
        'limit.page':this.data.limit.page+1,
      })
      setTimeout(()=>{
        this.onLoadDynamic()
      },1000)
    }
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})